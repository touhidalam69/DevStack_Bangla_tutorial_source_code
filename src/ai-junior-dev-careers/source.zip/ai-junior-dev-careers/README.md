# Product pages: the pagination bug from the video

A tiny Node.js product list, three products per page, used in the video to show why AI-written code needs a
reviewer. The AI-suggested `paginate` passed its tests, but page 2 showed four products: the page number came
from the URL as text, and `3 + '3'` is `'33'`.

This is the fixed version:

- `paginate.js` starts each page at `(page - 1) * pageSize`.
- `server.js` turns the URL values into numbers once, and answers `400 Bad Request` for anything that is not a
  whole number from 1.
- `paginate.test.js` checks that page 1 starts at the first item and page 2 continues after it.

Needs Node.js 22 or newer (the video used Node.js 25). No packages to install.

```
npm test     # runs node --test: 2 tests pass
npm start    # http://localhost:3000, then try ?page=2 and ?page=abc
```
