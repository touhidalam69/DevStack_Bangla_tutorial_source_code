# JobTrack, Episode 2: Entity Framework Core 10 + SQL Server

DevStack Bangla's full-stack series: ASP.NET Core Web API (.NET 10) + Angular 22.
Episode 2 moves the job list from an array in `Program.cs` into SQL Server with Entity Framework Core 10,
and adds create, read, update and delete endpoints.

Needs the .NET 10 SDK, SQL Server LocalDB (installed with Visual Studio, or with SQL Server Express) and
Node.js 24 LTS for the Angular app.

## Create the database

```
dotnet tool restore
cd JobTrack.Api
dotnet ef database update
```

`dotnet tool restore` installs `dotnet-ef` 10.0.12 from `dotnet-tools.json`. `database update` creates the
`JobTrack` database on `(localdb)\MSSQLLocalDB`, applies both migrations (`InitialCreate`, `AddAppliedOn`)
and adds three sample jobs (`Data/SeedData.cs`, run through `UseSeeding`).

LocalDB is Windows only. On another machine, point `ConnectionStrings:JobTrack` in
`JobTrack.Api/appsettings.json` at your own SQL Server.

## Run the API

```
dotnet run
```

It listens on `http://localhost:5032` (see `Properties/launchSettings.json`).

| Method | URL | What it does |
| --- | --- | --- |
| GET | `/api/jobs` | all jobs (no-tracking query) |
| GET | `/api/jobs/{id}` | one job, or 404 |
| POST | `/api/jobs` | add a job, 201 Created |
| PUT | `/api/jobs/{id}` | change a job, 204 No Content, or 404 |
| DELETE | `/api/jobs/{id}` | delete a job, 204 No Content, or 404 |

The calls from the video, in Windows PowerShell (`irm` is `Invoke-RestMethod`):

```
$api = 'http://localhost:5032/api/jobs'
irm $api/2
$j = '{"company":"Litware","role":"Intern","status":"Applied","appliedOn":"2026-10-08"}'
irm $api -Method Post -ContentType application/json -Body $j
$edit = '{"company":"Contoso","role":"Junior .NET Developer","status":"Rejected"}'
irm $api/1 -Method Put -ContentType application/json -Body $edit
irm $api/5 -Method Delete
irm $api | Format-Table
```

`JobTrack.Api/JobTrack.Api.http` has the same requests for Visual Studio, Rider or VS Code's REST Client.

## Run the Angular app

```
cd jobtrack-web
npm install
npx ng serve
```

Open http://localhost:4200. The page is the same as in episode 1; the data now comes from SQL Server.
