# JobTrack, Episode 7: Login with ASP.NET Core Identity

DevStack Bangla's full-stack series: ASP.NET Core Web API (.NET 10) + Angular 22.
Episode 7 adds users and a login. The API uses ASP.NET Core Identity's API endpoints with a cookie (httpOnly,
SameSite=Lax), not a JWT in localStorage: Microsoft's docs recommend cookies for browser apps because JavaScript
cannot read them. Every jobs endpoint needs a signed-in user, and deleting a job needs the Admin role
(401 without a cookie, 403 without the role). The Angular app has a login page, a route guard and an interceptor.

Needs the .NET 10 SDK, SQL Server LocalDB (installed with Visual Studio, or with SQL Server Express) and
Node.js 24 LTS for the Angular app.

## Create the database and run the API

```
dotnet tool restore
cd JobTrack.Api
dotnet user-secrets set "Seed:AdminPassword" "<a password of your own>"
dotnet ef database update
dotnet run
```

In Development the API creates an admin user, `admin@jobtrack.test`, with the password you put in user-secrets
(never in code or git). The password needs an uppercase and a lowercase letter, a digit and a symbol. Without the
secret, no admin is created. The API listens on `http://localhost:5032`.

LocalDB is Windows only. On another machine, point `ConnectionStrings:JobTrack` in
`JobTrack.Api/appsettings.json` at your own SQL Server.

## Try the API

```
api=localhost:5032/api
curl -i "$api/jobs"                                    # 401
curl "$api/auth/register" --json '{"email": "user@jobtrack.test", "password": "Jobs-2026"}'
curl -c cookies.txt "$api/auth/login?useCookies=true" \
  --json '{"email": "user@jobtrack.test", "password": "Jobs-2026"}'
curl -b cookies.txt "$api/jobs"                        # 200
curl -i -b cookies.txt -X DELETE "$api/jobs/22"        # 403: not an admin
```

`MapIdentityApi` adds `/api/auth/register`, `/login`, `/refresh`, `/manage/info` and more; `/api/auth/logout` is
our own endpoint.

## Run the Angular app

```
cd jobtrack-web
npm install
npx ng serve
npx ng test --watch=false
```

Open http://localhost:4200. `ng serve` sends every `/api` request to the API through `proxy.conf.json`, so the app
and the API share one origin and the cookie goes along without any CORS setting.

## What changed in this episode

| File | Change |
| --- | --- |
| `JobTrack.Api/Data/JobTrackDb.cs` | `IdentityDbContext<IdentityUser>` instead of `DbContext` |
| `JobTrack.Api/Migrations/*_AddIdentity.cs` | the AspNetUsers, AspNetRoles and other Identity tables |
| `JobTrack.Api/Program.cs` | `AddIdentityApiEndpoints`, `AddRoles`, the Admin policy, `MapIdentityApi` on `/api/auth`, a logout endpoint, `RequireAuthorization()` on the jobs and `RequireAuthorization("Admin")` on delete |
| `JobTrack.Api/Data/SeedData.cs` | `AddAdminAsync`: the Admin role and an admin user in Development |
| `jobtrack-web/proxy.conf.json`, `angular.json` | the dev server proxy for `/api` |
| `jobtrack-web/src/app/auth.ts` | `Auth`: who is signed in (asks `/api/auth/manage/info`), login, logout |
| `jobtrack-web/src/app/auth.guard.ts`, `app.routes.ts` | `authGuard` on the jobs page, `/login` route |
| `jobtrack-web/src/app/auth.interceptor.ts`, `app.config.ts` | a 401 from the API sends you to the login page |
| `jobtrack-web/src/app/login-page.*` | the login form (Signal Forms) |
| `jobtrack-web/src/app/jobs-page.*`, `app.*` | the list moved into `JobsPage`; `App` is the shell with the user and Sign out; a 403 on delete shows a message |
| `jobtrack-web/src/app/auth.guard.spec.ts`, `jobs-page.spec.ts` | guard tests, and the paging tests from Ep 6 |

`controller-version/` is from Episode 3: the same API written as a controller, for comparison. It is not part of
the build.
