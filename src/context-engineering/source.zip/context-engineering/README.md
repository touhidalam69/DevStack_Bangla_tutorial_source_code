# jobtrack-cli: context engineering experiment

Track your job applications from the terminal (Node.js, ES modules, no dependencies). This is the project from
DevStack Bangla's context engineering video, after the third of three Claude Code sessions.

The task was the same in all three: add a `stale` command that lists interviews nobody has followed up on.

| Run | Prompt | Context | `stale` threshold the agent chose | Team's rule (10 days) |
| --- | --- | --- | --- | --- |
| 1 | "Add a stale command that lists interviews that went stale." | the code only | 7 days | missed |
| 2 | a longer "senior Node.js developer, best practices" prompt | the code only | 7 days | missed |
| 3 | the same short prompt as run 1 | the code and `CLAUDE.md` | 10 days, from `lastContact` | followed |

`CLAUDE.md` holds what the code cannot tell: the commands, where things go, and the team's rules (an Interview is
stale after 10 days without contact). Claude Code loads it at the start of every session.

```
npm start              # list all applications
npm start status Offer # only one status
npm start followups    # Applied 7+ days ago
npm start stale        # Interviews with no contact for 10+ days
npm test               # run the tests
```

Data lives in `data/jobs.json`. Needs Node.js 22 or newer (tested on 26.12.1 and 24.21.0).
