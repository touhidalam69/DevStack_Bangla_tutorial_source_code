# JobTrack API: Node.js, TypeScript, PostgreSQL and Drizzle ORM

A small REST API for tracking job applications, from DevStack Bangla's Node.js REST API video. Node.js 26 runs
the TypeScript files directly (no build step), Express 5 serves the routes, zod validates every input, Drizzle ORM
talks to PostgreSQL 18, and drizzle-kit writes the SQL migrations.

| Method | Path | What it does |
| --- | --- | --- |
| GET | `/jobs?status=Interview` | all jobs, newest first; `status` is optional and checked |
| GET | `/jobs/:id` | one job, or 404 |
| POST | `/jobs` | add a job (201); status defaults to `Applied` |
| PATCH | `/jobs/:id` | change only the fields you send |
| DELETE | `/jobs/:id` | 204, or 404 |

Bad input gets a 400 with the message for each field.

## Run it

Needs Node.js 26 (`.nvmrc`) and Docker.

```
cp .env.example .env
docker compose up -d          # PostgreSQL 18 on port 5433
npm install
npx drizzle-kit migrate       # creates the jobs table
npm run dev                   # http://localhost:4000
```

The passwords in `compose.yaml` and `.env.example` are for local testing only.

## Check and test

```
npm run check                 # tsc --noEmit: Node runs TypeScript but does not check types
npm test                      # node --test: the validation rules, no database needed
```

After changing `src/db/schema.ts`, run `npx drizzle-kit generate --name <what-changed>` and then
`npx drizzle-kit migrate`.
