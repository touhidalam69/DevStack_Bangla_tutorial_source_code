# Node.js 26 LTS: what's new, with real code

DevStack Bangla's Node.js 26 video. A tiny job-application follow-up helper, written in TypeScript and run by
Node.js 26 directly, with no build step and no test framework installed:

- `src/old-date.js`: the classic `Date` bugs (months start at 0, and `Date` objects change in place)
- `src/follow-up.ts`, `src/jobs.ts`: the same follow-up dates with the Temporal API, which Node.js 26 turns on by default
- `src/interview.ts`: a 10:00 AM interview in Dhaka, in Toronto's time zone
- `src/month-end.ts`: January 31 plus one month, with `Date` and with Temporal
- `src/total.ts`: Node.js runs TypeScript but never checks its types; `tsc --noEmit` does
- `src/jobs.test.ts`: tests with the built-in `node:test` runner
- `src/group.ts`: `Map.prototype.getOrInsertComputed()` from V8 14.6
- `src/report.ts`: the permission model (`--permission`, `--allow-fs-read`, `--allow-net`)

Needs Node.js 26 (tested with v26.12.1). `.nvmrc` says 26, so `nvm use` picks it.

## Run it

```
npm install
node src/old-date.js
npm start
node src/interview.ts
node src/month-end.ts
node src/total.ts 3
node src/group.ts
```

## Check the types and run the tests

```
npm run check
npm test
```

`npm install` only adds TypeScript (for `tsc --noEmit`) and the Node.js types; running the code needs neither.

## Try the permission model

```
node --permission src/report.ts
node --permission --allow-fs-read=. src/report.ts
node --permission --allow-fs-read=. --allow-net src/report.ts
```

The first stops at reading `notes.txt` (`ERR_ACCESS_DENIED`), the second at the network call, and the third runs
(`--allow-net` still prints an experimental warning in Node.js 26).
