# JobTrack, Episode 1: Setup

DevStack Bangla's full-stack series: ASP.NET Core Web API (.NET 10) + Angular 22.

Needs the .NET 10 SDK and Node.js 24 LTS.

## Run the API

```
cd JobTrack.Api
dotnet run
```

It prints the address it listens on (`http://localhost:5032` here; the template picks a random port,
see `JobTrack.Api/Properties/launchSettings.json`). Open `/api/jobs` to see the JSON.

## Run the Angular app

```
cd jobtrack-web
npm install
npx ng serve
```

Open http://localhost:4200. If your API port is different, change it in `jobtrack-web/src/app/app.ts`.

## CORS

The API allows only `http://localhost:4200` (`AddCors` + `UseCors("AngularDev")` in `Program.cs`).
