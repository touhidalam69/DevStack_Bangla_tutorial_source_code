# JobTrack, Episode 5: Angular Signal Forms

DevStack Bangla's full-stack series: ASP.NET Core Web API (.NET 10) + Angular 22.
Episode 5 adds a form to add and edit jobs with Angular Signal Forms: validation rules with messages, submitting to
the API, a duplicate check against the API while you type (`validateHttp`), the API's own duplicate rule, and the
server's errors shown under the fields.

Needs the .NET 10 SDK, SQL Server LocalDB (installed with Visual Studio, or with SQL Server Express) and
Node.js 24 LTS for the Angular app.

## Create the database and run the API

```
dotnet tool restore
cd JobTrack.Api
dotnet ef database update
dotnet run
```

The API listens on `http://localhost:5032`.

LocalDB is Windows only. On another machine, point `ConnectionStrings:JobTrack` in
`JobTrack.Api/appsettings.json` at your own SQL Server.

## Run the Angular app

```
cd jobtrack-web
npm install
npx ng serve
```

Open http://localhost:4200. Type a company that is already in the list (Contoso) to see the duplicate check.

## What changed in this episode

| File | Change |
| --- | --- |
| `JobTrack.Api/Program.cs` | `GET /api/jobs/exists?company=...`; POST and PUT answer a company that is already in the list with a 400 ValidationProblem; routes with an id use `{id:int}` |
| `jobtrack-web/src/app/job.ts` | `appliedOn` on `Job`; `JobInput`, the shape the form edits |
| `jobtrack-web/src/app/job-form.ts` | the `JobForm` component: a `linkedSignal` model, `form()` with `required`, `maxLength`, `validate` and `validateHttp`, a submission action that POSTs or PUTs, and `toErrors()` for the API's 400 |
| `jobtrack-web/src/app/job-form.html` | `[formRoot]`, `[formField]` on every control, errors once a field is touched, Checking..., Saving..., Cancel |
| `jobtrack-web/src/app/job-form.css` | the form's styles |
| `jobtrack-web/src/app/app.ts`, `app.html`, `app.css` | the form next to the list, an Edit button per job, `editing` and `onSaved()` |

`controller-version/` is from Episode 3: the same API written as a controller, for comparison. It is not part of
the build and does not have this episode's duplicate rule.
