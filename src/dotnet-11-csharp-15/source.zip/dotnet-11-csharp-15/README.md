# .NET 11 and C# 15: union types, closed hierarchies and runtime async

DevStack Bangla. One small job-tracker service written twice, so you can see what C# 15 changes:

- `Before/`: .NET 10, C# 14. `SaveResult` is an abstract record with four results. The `switch` needs a `_` arm,
  and that arm silently swallows the new `Duplicate` result: the program prints "Something went wrong".
- `After/`: .NET 11, C# 15. `SaveResult` is a `union`. The `switch` has no `_` arm, and when a case is missing the
  build fails with `error CS8509` (the project turns that warning into an error).
- `trace/`: two file-based apps that print a live stack trace from three nested async methods, without and with
  runtime async.

Made with the .NET 11 SDK 11.0.100 (C# 15) and the .NET 10 SDK 10.0.401. `After/` and `trace/` need .NET 11;
`Before/` needs .NET 10.

## Run it

```
dotnet run --project Before
dotnet run --project After
```

`Before` prints:

```
Saved #4 Adatum
Job #42 not found
Company: Company is required
Something went wrong
```

`After` prints the same first three lines, then `contoso is already in your list`, followed by the union,
closed hierarchy, collection expression and labeled `break` examples.

To see the compiler catch a missing case, delete the `Duplicate d => ...` line in `After/Program.cs` and build:

```
error CS8509: The switch expression does not handle all possible values of its input type
(it is not exhaustive). For example, the pattern 'Duplicate' is not covered.
```

## Runtime async

```
cd trace
dotnet run trace.cs      # 13 frames: the compiler's async state machine shows up
dotnet run trace-on.cs   # 5 frames: only your methods
```

`trace-on.cs` turns runtime async on with `#:property Features=runtime-async=on`. In a project, the same switch is
`<Features>runtime-async=on</Features>` in the `.csproj`.

## Files

| File | What it shows |
| --- | --- |
| `Before/Results.cs` | the C# 14 way: an abstract record and four derived records |
| `After/Results.cs` | `public union SaveResult(Saved, NotFound, Invalid, Duplicate);` |
| `After/JobService.cs` | `Save()` returns a case record; the union conversion is implicit |
| `After/JobStatus.cs` | a `closed` record: only this assembly can derive from it |
| `After/Program.cs` | exhaustive `switch` expressions, the union's `Value`, JSON, `default`, `with(...)`, labeled `break` |
| `After/After.csproj` | `net11.0` and `<WarningsAsErrors>CS8509</WarningsAsErrors>` |
| `trace/trace.cs`, `trace/trace-on.cs` | live stack traces without and with runtime async |
