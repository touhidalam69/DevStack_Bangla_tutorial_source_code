# Check a survey headline yourself

`check-trust.mjs` downloads one published table of the Stack Overflow Developer Survey 2026
(`AITrust`: "How much do you trust the output from AI tools or AI agents as part of your workflow?"),
adds up the answers and prints the share of each "I trust it ..." answer.

Run it with Node.js 22 or newer (the video used Node.js 24 LTS). No packages to install.

```
node check-trust.mjs
```

Output on 2026-10-08:

```
Respondents: 14304
48.0% I trust it when I can easily verify the output
16.3% I trust it for many tasks, but not important work decisions
16.3% I trust it for low-risk work tasks only
6.6% I trust it for many tasks, including important work decisions
Any "I trust it" answer: 87.2%
```

Data: https://survey.stackoverflow.co/2026/ai/data/ai-trust (Stack Overflow Developer Survey 2026,
licensed under the Open Database License 1.0).
