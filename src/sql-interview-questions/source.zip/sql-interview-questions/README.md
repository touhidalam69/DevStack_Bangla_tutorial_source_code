# SQL Interview Questions: 10 queries with real results

DevStack Bangla. Ten SQL questions that come up in interviews: JOIN, NULL, GROUP BY and window functions.
Each question is a small query on a six-row sample database: guess the result, then run it.

Made with SQL Server 2025 (LocalDB 17.0.4025.3) and sqlcmd. Any SQL Server 2017 or newer gives the same results;
LocalDB and Express are free.

## Set up

Git Bash (macOS and Linux shells are the same):

```
export SQLCMDSERVER="(localdb)\MSSQLLocalDB"
sqlcmd -i setup.sql
export SQLCMDDBNAME=SqlInterview
sqlcmd -i data.sql
```

PowerShell:

```
$env:SQLCMDSERVER = "(localdb)\MSSQLLocalDB"
sqlcmd -i setup.sql
$env:SQLCMDDBNAME = "SqlInterview"
sqlcmd -i data.sql
```

With another server, set `SQLCMDSERVER` to its name (add `-U` and `-P` for SQL logins).

## Run a question

```
sqlcmd -i questions/q05.sql
sqlcmd -i questions/q05-fix.sql
```

## The questions

| # | File | Topic | Result |
| --- | --- | --- | --- |
| 1 | `q01.sql` | LEFT JOIN: how many rows? | 6 |
| 2 | `q02.sql`, `q02-fix.sql` | LEFT JOIN with a WHERE on the right table | 3 (Sales disappears); condition in `ON`: 4 |
| 3 | `q03.sql` | `COUNT(*)`, `COUNT(column)`, `COUNT(DISTINCT column)` | 6, 5, 2 |
| 4 | `q04.sql`, `q04-fix.sql` | `= NULL` vs `IS NULL` | 0, then 1 |
| 5 | `q05.sql`, `q05-fix.sql` | `NOT IN` with a NULL in the list | no rows; `NOT EXISTS`: 3 rows |
| 6 | `q06.sql`, `q06-where.sql` | `WHERE` vs `HAVING` | one row; an aggregate in `WHERE` is error 147 |
| 7 | `q07.sql` | a column that is neither grouped nor aggregated | error 8120 |
| 8 | `q08.sql`, `q08-fix.sql` | an alias in `WHERE` | error 207; the fix returns 3 rows |
| 9 | `q09.sql`, `q09-top.sql` | `RANK` vs `DENSE_RANK`; top earner per department | Karim: 3 and 2 |
| 10 | `q10.sql`, `q10-fix.sql` | second highest salary | `OFFSET 1` gives 90000 (wrong, a tie); the fixes give 70000 |

Open the file, guess first, then run it.
