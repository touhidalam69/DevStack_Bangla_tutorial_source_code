# Jev ticket router (C#)

A small .NET 10 console app that asks **Jev**, TypeSafe's System One model, typed questions about a support
ticket and a bug report. It reads the typed answers (Choice, Score, Noul), checks the confidence with the formula
from TypeSafe's docs, and routes the ticket in code: act alone only when Jev is sure.

## Without an API key: the stub

Jev's API was in early access when this was made, so the video runs against `JevStub`, a tiny local server that
answers `POST /v1/systemone` with the **sample responses TypeSafe published in its docs** (`JevStub/samples/`, each
with its source page). No model runs in the stub: any other text gets `404`.

```bash
# terminal 1
cd JevStub
dotnet run                      # http://localhost:5199

# terminal 2
export TYPESAFE_BASE_URL=http://localhost:5199
export TYPESAFE_API_KEY=demo-key
dotnet run --project TicketRouter            # the support ticket
dotnet run --project TicketRouter -- bug     # the bug report
```

## With a real key

Create a key in the [TypeSafe console](https://console.typesafe.ai/), set `TYPESAFE_API_KEY`, and leave
`TYPESAFE_BASE_URL` unset: the same code then calls `https://api.typesafe.ai/v1/systemone`. Pricing on
2026-10-12: $0.042 per million input tokens, output tokens free ([Models](https://docs.typesafe.ai/models)).

## Files

| File | What it does |
| --- | --- |
| `TicketRouter/Jev.cs` | the answer records, the three question types (`Q.Choice`, `Q.Score`, `Q.Noul`) and `JevClient` |
| `TicketRouter/Confidence.cs` | confidence from the probabilities, formulas from [docs.typesafe.ai/confidence](https://docs.typesafe.ai/confidence) |
| `TicketRouter/Program.cs` | the two requests and the routing thresholds |
| `JevStub/Program.cs` | the local stand-in for the API |

Versions: .NET SDK 10.0.401, model `jev-1.13.0` (in the published samples).
