# jobtrack-cli

Track your job applications from the terminal.

```
npm start              # list all applications
npm start status Offer # only one status
npm test               # run the tests
```

Data lives in `data/jobs.json`.
