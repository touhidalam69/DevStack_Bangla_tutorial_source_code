# JobTrack, Episode 4: Angular Signals and httpResource

DevStack Bangla's full-stack series: ASP.NET Core Web API (.NET 10) + Angular 22.
Episode 4 is about the Angular app. It shows why Angular 22 (zoneless, OnPush by default) needs signals, adds a
status filter with counts using `computed`, loads the jobs with `httpResource` (loading, error and Retry states),
and deletes a job with `HttpClient`, then reloads the list.

Needs the .NET 10 SDK, SQL Server LocalDB (installed with Visual Studio, or with SQL Server Express) and
Node.js 24 LTS for the Angular app.

## Create the database and run the API

```
dotnet tool restore
cd JobTrack.Api
dotnet ef database update
dotnet run
```

The API listens on `http://localhost:5032`. The API does not change in this episode.

LocalDB is Windows only. On another machine, point `ConnectionStrings:JobTrack` in
`JobTrack.Api/appsettings.json` at your own SQL Server.

## Run the Angular app

```
cd jobtrack-web
npm install
npx ng serve
```

Open http://localhost:4200. Stop the API and press Retry to see the error state.

## What changed in this episode

| File | Change |
| --- | --- |
| `jobtrack-web/src/app/app.ts` | `httpResource` instead of `HttpClient.subscribe`; `filter` signal; `shown` and `counts` computed; `hasValue()` before `value()`; `remove()` with `HttpClient.delete`, then `jobs.reload()` |
| `jobtrack-web/src/app/app.html` | status filter buttons with counts, loading and error states with Retry, a Delete button per job |
| `jobtrack-web/src/app/app.css` | styles for the filter, Retry and Delete buttons |
| `jobtrack-web/src/app/app.spec.ts` | answers the `httpResource` request with `HttpTestingController`, so `whenStable()` resolves |
| `jobtrack-web/try/signals.mts` | `signal`, `set`, `update` and `computed` outside a component: `node try/signals.mts` (Node.js 24 runs it as is) |

`controller-version/` is from Episode 3: the same API written as a controller, for comparison. It is not part of
the build.
