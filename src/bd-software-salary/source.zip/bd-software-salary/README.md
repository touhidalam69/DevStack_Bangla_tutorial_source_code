# Software engineer salaries in Bangladesh, by experience

The small Node.js project from the video. It reads a salary table published in May 2026 (people filled in a
Google Form with their company, title, years of experience and monthly salary in Tk) and prints the median monthly
salary for each band of experience. A second script compares job offers by what they pay in a year.

Source of the table: [What Bangladeshi Tech Companies Are Paying Employees in 2026](https://tahanima.github.io/what-bangladeshi-tech-companies-are-paying-employees-in-2026/)
(May 2, 2026). The author's own note: "the data may not be entirely accurate". The data is not copied here:
`npm run fetch` downloads the page on your machine.

## Run it

Node.js 24 or later, no packages to install.

```
npm run fetch      # downloads the page, saves its table to .cache/pay-2026.json
npm run analyze    # median monthly salary by years of experience, engineering and QA roles
npm run offer -- 52000:2:0.5 50000:2:1    # monthly:bonuses:bonus share, one per offer
npm test           # unit tests, no network
```

What `analyze` does:

- keeps engineering and QA titles; interns, trainees and other roles (analyst, designer, officer) are counted apart;
- a salary range counts as its midpoint, and so does a range of years ("0-3" is 1.5, "<2" is 1, "2+" is 2);
- an amount it cannot read for sure ("Tk. 50,00": fifty thousand or five thousand?) is left out, not guessed.

The result on 2026-11-21 (70 rows, 56 engineering):

```
years    rows  median      lowest-highest
0-1 yrs    21  Tk 42,500   25,000-67,500
2-3 yrs    22  Tk 69,000   25,000-115,000
4-5 yrs    12  Tk 117,500  85,000-270,000
6+ yrs      1  Tk 500,000  500,000-500,000
```

Self-reported data from people who chose to fill in a form: read it as one market, not the whole country.
