# Modern C# Features: old-style code rewritten with records, patterns and C# 14

DevStack Bangla. A small job tracker written twice: `Before/` in the old style, `After/` with modern C# features.
Both programs print exactly the same output.

Needs the .NET 10 SDK (made with SDK 10.0.401, C# 14). `After/` uses C# 14 features (`field`, extension members),
so it needs .NET 10 or newer.

## Run it

```
dotnet run --project Before
dotnet run --project After
```

Check that both print the same (Git Bash, macOS or Linux):

```
dotnet run --project Before > before.txt
dotnet run --project After > after.txt
diff before.txt after.txt && echo "Same output"
```

## Before and after

| File | Before | After | Feature (C# version) |
| --- | --- | --- | --- |
| `JobApplication.cs` | class with constructor, Equals, GetHashCode, `==`, `!=`, ToString (34 lines) | positional record (2 lines) | records (C# 9) |
| `NextStep.cs` | if-else chain | switch expression with property and relational patterns | patterns (C# 8, 9) |
| `FollowUpService.cs` | private readonly fields + constructor | primary constructor | primary constructors (C# 12) |
| `Program.cs` | `new List<JobApplication> { new JobApplication(...) }` | `[new(...), ...]` and `with` | collection expressions (C# 12), target-typed `new` (C# 9) |
| `Contact.cs` | backing field `_email` | `set => field = ...` | `field` keyword (C# 14) |
| `JobExtensions.cs` | extension methods `IsOpen()`, `OpenCount()` | `extension` blocks with properties `IsOpen`, `OpenCount` | extension members (C# 14) |

## The three quiz questions

Small file-based apps in `quiz/` (a .NET 10 feature: run one `.cs` file without a project). Guess first, then run:

```
cd quiz
dotnet run q1-equality.cs
```

| File | Question | Output |
| --- | --- | --- |
| `q1-equality.cs` | a record with a `List<string>`: are two records with the same data equal? | `False` |
| `q1-fix.cs` | compare the lists' items with `SequenceEqual` | `False` `True` |
| `q2-order.cs` | a general switch arm before a specific one | fails to build on purpose: `error CS8510` |
| `q2-if.cs` | the same order as an if-else chain | `Wait` (no error, wrong answer) |
| `q3-counter.cs` | a primary constructor parameter changed by a method | `7` |
