# A freelance gig, done by an AI agent

The demo from the DevStack Bangla video on AI and Bangladesh's IT and freelancing jobs.

A Dhaka gadget shop sends six invoices (`invoices/`) and a short brief (`brief.txt`): one CSV with the date,
invoice number, customer and total. That is a typical small data-entry gig.

- `invoices.csv` is what Claude Code (2.1.295, `claude -p` with the brief as the prompt) wrote in about 18 seconds.
- `check.mjs` is the client's own check, written before the session: the shop's dates are day/month/year, invoice
  1042 has a 10% discount, and one customer's name has a comma in it.

Run the check (Node.js 22 or newer, no packages):

```
npm test
```

It prints one line per invoice and `all 6 rows right`.
