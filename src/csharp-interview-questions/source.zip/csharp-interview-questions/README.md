# C# Interview Questions 2026: 10 questions with running code

DevStack Bangla. Ten "what does this print?" questions that come up in C# interviews. Each question is a small,
real program: guess the output, then run it and check.

Needs the .NET 10 SDK (made with SDK 10.0.401, C# 14). Question 10 uses a C# 14 feature, so it needs .NET 10 or newer.

## Run a question

```
cd InterviewQuestions
dotnet run -- 6
```

Without a number it lists the questions. Some questions have a second version that shows the fix: `5-fix`,
`6-fix` and `9-fix` (that one throws on purpose).

## The questions

| # | File | Topic | Output |
| --- | --- | --- | --- |
| 1 | `Questions/Q01.cs` | struct vs class: copying a value or a reference | `0 5` |
| 2 | `Questions/Q02.cs` | `==` vs `Equals` on `string` and `object` | `True` `False` `True` |
| 3 | `Questions/Q03.cs` | boxing copies the value | `5` |
| 4 | `Questions/Q04.cs` | a `List` passed to a method: change it vs replace it | `1,2` |
| 5 | `Questions/Q05.cs` | a lambda in a `for` loop captures one shared `i` | `333` (fix: `012`) |
| 6 | `Questions/Q06.cs` | LINQ deferred execution | `3` (with `ToList()`: `2`) |
| 7 | `Questions/Q07.cs` | record vs class equality | `True` `False` |
| 8 | `Questions/Q08.cs` | `return` inside `try` with `finally` | `finally 1` |
| 9 | `Questions/Q09.cs` | `int.MaxValue + 1` (unchecked by default) | `-2147483648` (with `checked`: `OverflowException`) |
| 10 | `Questions/Q10.cs` | C# 14 null-conditional assignment | `no profile` |

Open the file, guess first, then run it.
